<?php




	$link = $_POST["link"];
	$username = $_POST["username"];
	$pwd = $_POST["pwd"];
	$name = $_POST["name"];




	

       		

				$content = '<div class="box" style="clear: both;line-height:1.8;padding-left: 4%;
				      padding-top: 2%;
				      padding-right: 2%;
				      padding-bottom: 0.5%;">
				        <b>
				        <span>
				          Dear '.$name.',
				        </span> 
				      </b>
				      <br><br>


				    <div>Kindly find below login credentials.</div><br>
				    <div style="margin-top:5px;">Login Link : '.$link.'</div>
				    <div style="margin-top:5px;">Login ID : '.$username.'</div>
				    <div style="margin-top:5px;">Password : '.$pwd.'</div>
			
				      
				    
				    
				     
				  </div>';


				  




			  $subject = "MT4 Account Data - Live Monitoring";

			
			  $mailbody = $content;

			  if(mailphpfunc($mailbody,$subject,$username,$firstName)=='1')
				{
					echo '1';
				}
				else
				{
					echo '2';
				}











       function mailphpfunc($mailbody,$subject,$email,$name)
		{
			global $adminpassword;
			global $adminEmailid;
			// require_once './PHPMailer/PHPMailerAutoload.php';
			require_once (__DIR__.'/./PHPMailer/PHPMailerAutoload.php');
			$mail = new PHPMailer;
			//$mail->SMTPDebug = 1;                                  // Enable verbose debug output
			//$mail->isSMTP();                                         // Set mailer to use SMTP
			$mail->Host = 'smtp.lolipop.jp';                      // Specify main and backup SMTP servers
			$mail->SMTPAuth = true;                                  // Enable SMTP authentication
			$mail->Username = 'noreply@ai-ibl.jp';                 // SMTP username
			$mail->Password = 'DbtSEc_4DS5gbsiPk';                          // SMTP password
			$mail->SMTPSecure = 'tls';                               // Enable TLS encryption, `ssl` also accepted
			$mail->Port = 465;                                      // TCP port to connect to
			
			//echo "email fucntion called ";
			$mail->setFrom('noreply@ai-ibl.jp');
			$mail->addAddress($email);
			
			
			$mail->isHTML(true);                                       // Set email format to HTML
		
		
			
			$mail->Subject = $subject;
			$mail->msgHTML($mailbody);
			//echo "mail function called ";
			$mail->AltBody = "To view the message, please use an HTML compatible email viewer!";
			
			if(!$mail->send()) {
			   //echo '2';
			   //$conn->close();
			   //echo 'Mailer Error: '. $mail->ErrorInfo;
			   return '2';
			}
			else{

			  //echo '1';
			  return '1';
			  //$conn->close();
			}
		}








			




?>