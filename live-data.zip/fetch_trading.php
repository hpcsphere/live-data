 <?php
 require_once('config.php');

  date_default_timezone_set("Asia/Kolkata");

    $i = 1;

   $sql = "SELECT * FROM Live_Trading_Data WHERE 1";
   $result=$con->query($sql);
   $arr = array();
   while($row = $result->fetch_assoc()) {

      // $crt = date('H:i');

    //  $crt = gmdate('H:i');

    //   $oot = date('H:i', strtotime(str_replace('.', '-', $row["ORDER_OPEN_TIME"]) ));


    //   $time1 = new DateTime($crt);
    //   $time2 = new DateTime($oot);
    //   $interval = $time1->diff($time2);

    $crt = gmdate('Y-m-d G:i');
    $oot = date('Y-m-d G:i', strtotime(str_replace('.', '-', $row["ORDER_OPEN_TIME"]) ));

    $time1 = new DateTime($crt);
    $time2 = new DateTime($oot);
    $interval = $time1->diff($time2);

    $days_val = intval($interval->format('%a'));
    $hours_val = ($days_val * 24) + intval($interval->format('%h'));
    $min_val = intval($interval->format('%i'));

      $act = 0;
  $dep = 0;
  $eq = 0;
  $pr = 0;
  $wi = 0;

      
      $sql2 = "SELECT COUNT(*) as act FROM `Live_Trading_Data` WHERE 1;";
     $result2=$con->query($sql2);
     while($row2 = $result2->fetch_assoc()) {
      $act = $row2["act"];
     }

       $sql1 = "SELECT * FROM `Live_Trading_Data` WHERE 1;";
       $result1=$con->query($sql1);
       while($row1 = $result1->fetch_assoc()) {
        $dep = $row1["Deposit"]+$dep;
        $eq = $row1["Account_Equity"]+$eq;
        $pr = $row1["Profit_Amt"]+$pr;
        $wi = $row1["Withdraw"]+$wi;
       }



        if($row["ORDER_OPEN_TIME"]==null || $row["ORDER_OPEN_TIME"]=="" ){

          array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => "NA", 'act' => round($act, 2), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));

    }else{
      //array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => round($row["Account_Equity"], 2), 'Margin_Level' => round($row["Margin_Level"], 2), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => round($row["Account_Balance"], 2), 'Profit_Per' => round($row["Profit_Per"], 2), 'Profit_Amt' => round($row["Profit_Amt"], 2), 'Deposit' => round($row["Deposit"], 2), 'Withdraw' => round($row["Withdraw"], 2), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $interval->format('%H h %i m ago'), 'act' => round($act, 2), 'dep' => round($dep, 2), 'eq' => round($eq, 2), 'pr' => round($pr, 2), 'wi' => round($wi, 2) ));
      if ($time1 > $time2) {
        // array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m ago", 'act' => number_format($act, 2,".",""), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));

        // new1

         array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m ago", 'act' => round($act, 2), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));


      } else {
        // array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m", 'act' => number_format($act, 2,".",""), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));



        // new1

        array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m", 'act' => round($act, 2), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));


      }

    }



   }
   echo json_encode($arr);

?>