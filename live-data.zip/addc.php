<?php
	
 date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)

require_once('config.php');

  $name = filter_input(INPUT_POST, 'name');
  $username = filter_input(INPUT_POST, 'username');

  $pwd =filter_input(INPUT_POST, 'pwd'); 

  $mt4 =filter_input(INPUT_POST, 'mt4'); 

  $lang =filter_input(INPUT_POST, 'lang'); 

 $sql1="SELECT * FROM login WHERE Username='$username' ";
  $result1=mysqli_query($con,$sql1);

  $arr = array();
  $arr = explode (",", $mt4);
  echo "arr=".$arr;
  $num = 0;
  foreach($arr as $x){
    $sql2="SELECT * FROM 'Live_Trading_Data' WHERE Account_Number='$x'";
    $result2=mysqli_query($con,$sql2);
    $num = $num + mysqli_num_rows($result2);
  }

  echo "num=".$num;

  if( mysqli_num_rows($result1)==1){

    echo "duplicate";

  }else{

    $sql = "INSERT INTO `login`(`Username`, `Password`, `Name`, `MT4_Account`, `Language` ) VALUES ('".$username."','".$pwd."','".$name."','".$mt4."','".$lang."' ) ";
    $result=$con->query($sql);

    echo $sql;

  }

    
?>