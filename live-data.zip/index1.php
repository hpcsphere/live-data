<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html>
<head>
 

 <title class="adlm">MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>
<style>

  .btns {

        width: 100px;
    overflow-x: hidden;
    cursor: default ! important;
    background-color: #ccc;
  }

  .btd {
        margin-left: 10px;
            padding: 5px;
  }

  .bord {
        border-left: 1px solid lightgrey;
    padding-left: 10px;
  }


  .logout {
        position: absolute;
    right: 20px;
    top: 20px;
    font-size: 20px;
    cursor: pointer;
    color: red;
  }

  .header {
    height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
  }

  .custom-select-sm {
        width: 50px;
  }

  .dataTables_filter>label {
        display: inline-flex;
  }


  .redcol {
     background-color: #f59a9a;
  }

  .grecol {
    background-color: lightgreen;
  }

  #table_wrapper {
        width: 103%;
  }

</style>
<body>

  <header class="header" style=" 
     "><span class="adlm">MT4 Account Data - Live Monitoring</span>


<a href="logout.php"><i class="fa fa-sign-out logout" aria-hidden="true" title="Logout" ></i></a>





   </header> 

    

<br><br>
<div class="container" style="padding-left: 0px;position: relative;right: 10px;">

  <!-- <div align="center">
      <div class="form-group" style="display: inline-flex;width: 100%;justify-content: center;">
        <form>
          <label>Symbol:</label>
          <input type="text" name="Symbol" id="symbol" placeholder="Please enter Symbol" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;
          <label>Entry Price:</label>
        <input type="text" name="Entry Price" id="price" placeholder="Please enter Entry Price" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;

         <label>Signal:</label>
       <select id="signal" style="height: 28px;width: 70px;">
        <option class="null">Buy</option>
        <option>Sell</option>
       </select>&nbsp;&nbsp;

          <button class="btn btn-success add"><i class="fa fa-plus"></i>&nbsp;&nbsp;<i class="fa fa-spinner fa-spin" style="font-size: 17px;position: absolute;margin-top: -1px;display:none ;"></i>Add Trading Point</button>
        </form>
      </div>
     
    </div>

     <span style="    font-size: 15px;
    color: green;
    position: absolute;
    left: 42%;
    margin-top: 12px;">

      <?php echo date("d-M-Y"); echo " ";

        $date = new DateTime();
        $timeZone = $date->getTimezone();
        echo $timeZone->getName();



       ?>
       <span id="zone"></span>
     </span> -->

          
 <!--  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    <th>Account Number</th>
    <th>Account Equity</th>
    <th>Margin Level %</th>
    <th>Highest Position Symbol </th>
    <th>highest Position Lot Size</th>
  </tr>
</thead>
<tbody>
 
</tbody>
</table> -->


<div style="display: flex;border: 1px solid lightgrey;    width: 103%;">


 <?php

  $act = 0;
  $dep = 0;
  $eq = 0;
  $pr = 0;
  $wi = 0;

    $arr = array();
    $sql = "SELECT * FROM login WHERE Username = '".$_SESSION['username']."' ";
    $result=$con->query($sql);
    $row = $result->fetch_assoc();
    $arr = explode (",", $row["MT4_Account"]);


    $lang = $row["Language"];


    foreach($arr as $x)
    {
      $sql = "SELECT * FROM `Live_Trading_Data` WHERE Account_Number= '$x' ";
      $result=$con->query($sql);
      $row = $result->fetch_assoc();
      $act += 1;
      $dep += floatval($row["Deposit"]);
      $eq += floatval($row["Account_Equity"]);
      $pr += floatval($row["Profit_Amt"]);
      $wi += floatval($row["Withdraw"]);
    } // end of foreach
  ?>


 <div class="btd">
    <b class="tnoa">Total number of accounts</b>
    <button class="btn btn-default btns act"><?php echo round($act, 2); ?></button>
  </div>
  <div class="btd bord">
    <b class="td">Total Deposit</b>
    <button class="btn btn-default btns dep"><?php echo number_format($dep, 2,".",""); ?></button>
  </div>
  <div class="btd bord">
    <b class="te">Total Equity</b> 
    <button class="btn btn-default btns eq"><?php echo number_format($eq, 2,".","");  ?></button>
  </div>
  <div class="btd bord">
    <b class="tp">Total Profit</b>
    <?php 
      if(number_format($pr, 2,".","")>0){
    ?>

    <button class="btn btn-default btns pr grecol"><?php echo number_format($pr, 2,".",""); ?></button>

      <?php 
      }else{
    ?>

    <button class="btn btn-default btns pr redcol"><?php echo number_format($pr, 2,".",""); ?></button>

    <?php 
      }
    ?>

  </div>
  <div class="btd bord">
    <b class="tw">Total Withdraw</b>
    <button class="btn btn-default btns wi"><?php echo number_format($wi, 2,".",""); ?></button>
  </div>

</div><br>






  
  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th class="sl">Sl.No.</th>
    <th class="an">Account Name</th>
    <th class="anum">Account Number</th>
    <th class="ab">Account Balance</th>
    <th class="dl">Deposit</th>
    <th class="wl">Withdraw</th>
    <th class="ae">Account Equity</th>
    <th class="ml">Margin Level %</th>
    <th class="tpl">Today's Profit&nbsp;(&nbsp;$&nbsp;)</th>
    <th class="tpl1">Total Profit&nbsp;(&nbsp;$&nbsp;)</th>
    <th class="hps">Highest Position Symbol </th>
    <th class="hpls">Highest Position Lot Size</th>
    <th class="hps1">Highest Position Signal</th>
    <th class="lp">Last&nbsp;Position&nbsp;Time</th>
  </tr>
</thead>
<tbody>
 <?php
 require_once('config.php');

    $arr = array();
    $sql = "SELECT * FROM login WHERE Username = '".$_SESSION['username']."' ";
    $result=$con->query($sql);
    $row = $result->fetch_assoc();
    // array_push($arr, $row["MT4_Account"]);
    $arr = explode (",", $row["MT4_Account"]);

    $i = 1;

    foreach($arr as $x)
      {
        
        $sql = "SELECT * FROM Live_Trading_Data WHERE Account_Number= '$x' ";
        $result=$con->query($sql);
        while($row = $result->fetch_assoc()) {



          echo "<tr class='tr'>";
          echo "<td><center>".$i."</center></td>";

           $i++;

          echo "<td>".$row["Account_Name"]."</td>";
          echo "<td>".$row["Account_Number"]."</td>";
          // echo "<td>".round($row["Account_Balance"], 2)."</td>";
          echo "<td align ='right'>".number_format($row["Account_Balance"], 2,".","")."</td>";
        if($row["Deposit"]>=0){
            // echo "<td>".round($row["Deposit"], 2)."</td>";
            echo "<td align ='right'>".number_format($row["Deposit"], 2,".","")."</td>";
          }else{
            // echo "<td style='background: #f59a9a;'>".round($row["Deposit"], 2)."</td>";
            echo "<td align ='right' style='background: #f59a9a;'>".number_format($row["Deposit"], 2,".","")."</td>";
          }
          // echo "<td>".round($row["Withdraw"], 2)."</td>";
          echo "<td align ='right'>".number_format($row["Withdraw"], 2,".","")."</td>";
          echo "<td align ='right'>".number_format($row["Account_Equity"], 2,".","")."</td>";

          if($row["Margin_Level"]>400){
            echo "<td align ='right' style='background: lightgreen;' class='ml1'>".number_format($row["Margin_Level"], 2,".","")."</td>";
          }else{
            echo "<td align ='right' style='background: #f59a9a;' class='ml1'>".number_format($row["Margin_Level"], 2,".","")."</td>";
          }

          // echo number_format($row["Profit_Per"],2,".","")."<br>";

          if($row["Profit_Per"]>=0){
            // echo "<td>".round($row["Profit_Per"], 2)."</td>";
            echo "<td align ='right'>".number_format($row["Profit_Per"], 2,".","")."</td>";
          }else{
            // echo "<td style='background: #f59a9a;'>".round($row["Profit_Per"], 2)."</td>";
            echo "<td align ='right' style='background: #f59a9a;'>".number_format($row["Profit_Per"], 2,".","")."</td>";
          }


          if($row["Profit_Amt"]>=0){
            // echo "<td>".round($row["Profit_Amt"], 2)."</td>";
            echo "<td align ='right'>".number_format($row["Profit_Amt"], 2,".","")."</td>";
          }else{
            // echo "<td style='background: #f59a9a;'>".round($row["Profit_Amt"], 2)."</td>";
            echo "<td align ='right' style='background: #f59a9a;'>".number_format($row["Profit_Amt"], 2,".","")."</td>";
          }

          echo "<td>".$row["Highest_Position_Symbol"]."</td>";
          echo "<td align ='right'>".$row["Highest_Position_Lot_Size"]."</td>";

          if(strtolower($row["Highest_Position_Signal"])== "buy" ){
            echo "<td style='background: lightgreen;'>".$row["Highest_Position_Signal"]."</td>";
          }else if(strtolower($row["Highest_Position_Signal"])== "sell" ){
            echo "<td style='background: #f59a9a;'>".$row["Highest_Position_Signal"]."</td>";
          }else{
            echo "<td>".$row["Highest_Position_Signal"]."</td>";
          }
        
          if($row["ORDER_OPEN_TIME"]==null || $row["ORDER_OPEN_TIME"]=="" ){

            echo "<td>NA</td>";
            // echo "<td>-</td>";

          }else{

              // $crt = date('H:i');

              // $crt = gmdate('H:i');
              $crtx = gmdate('Y-m-d G:i');

              // $oot = date('H:i', strtotime(str_replace('.', '-', $row["ORDER_OPEN_TIME"]) ));
              $ootx = date('Y-m-d G:i', strtotime(str_replace('.', '-', $row["ORDER_OPEN_TIME"]) ));

              // $time1 = new DateTime($crt);
              // $time2 = new DateTime($oot);
              // $interval = $time1->diff($time2);

              $t1 = new DateTime($crtx);
              $t2 = new DateTime($ootx);
              $intervalx = $t1->diff($t2);

              $days_val = intval($intervalx->format('%a'));
              $hours_val = ($days_val * 24) + intval($intervalx->format('%h'));
              $min_val = intval($intervalx->format('%i'));

              // echo "<td>". $intervalx->format('%a d %H h %i m ago')."</td>";
              // echo "<td>". $intervalx->format('%H h %i m ago')."</td>";

              // if ($row["Account_Number"] == "310231229"){
              //   echo "310231229<br>";
              //   echo "Order open: ". $row["ORDER_OPEN_TIME"]."<br>";
              //   echo "crt :".$crtx."<br>";
              //   echo "oot :".$ootx."<br>";
              //   echo "days_val :".$days_val."<br>";
              //   echo intval($intervalx->format('%h')) . "<br>";
              // }

              if ($t1 > $t2) {
                echo "<td>". $hours_val ." h ".$min_val." m ago</td>";
              } else {
                echo "<td>". $hours_val ." h ".$min_val." m</td>";
              }


              // echo "<td>-</td>";

            }

        

          
          echo "</tr>";

         

      }
   }
   

  ?>
</tbody>
</table>




</div>


<div id="deleteModal" class="modal">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
             <h4 class="modal-title">Trade Points Management</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
           
          </div>
          <div class="modal-body">
            <p>Do you really want to delete?</p>
          </div>
          <div class="modal-footer">
            <!-- <p style="color: green;position: absolute;left: 17px;display: none;" id="pd"><i class="fa fa-check"></i>&nbsp;Project Deleted Successfully.</p> -->
            <!-- <p style="color: red;position: absolute;left: 17px;display: none;" id="pnd"><i class="fa fa-times"></i>&nbsp;Project Not Delete!</p> -->
        <button type="button" class="btn btn-danger yes"><i class="fa fa-check"></i><i class="fa fa-spinner fa-spin" style="font-size: 17px;position: absolute;margin-top: -1px;display:none ;"></i>&nbsp; Yes</button>
        <button type="button" class="btn btn-default cl" data-dismiss="modal" style="border: 1px solid lightgrey;"><i class="fa fa-times"></i>&nbsp; No</button>
          </div>
        </div>

      </div>
    </div>


    <div id="abv16" class="modal">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
             <h4 class="modal-title">Trade Points Management</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
           
          </div>
          <div class="modal-body">
            <p>16 trading points have already been defined for today <?php echo date("d-M-Y"); ?></p>
          </div>
          <div class="modal-footer">
            <!-- <p style="color: green;position: absolute;left: 17px;display: none;" id="pd"><i class="fa fa-check"></i>&nbsp;Project Deleted Successfully.</p> -->
            <!-- <p style="color: red;position: absolute;left: 17px;display: none;" id="pnd"><i class="fa fa-times"></i>&nbsp;Project Not Delete!</p> -->
       
        <button type="button" class="btn btn-default cl" data-dismiss="modal" style="border: 1px solid lightgrey;"><i class="fa fa-times"></i>&nbsp; Close</button>
          </div>
        </div>

      </div>
    </div>




<script>

 
  

  

 
// $.post("fetch.php",
//       {
        
//       },function(data)
//       {
        
//         $("#tbdiv").html(data);

//         var table = $('#table').DataTable({
//         "iDisplayLength": 100,
//          "aaSorting": [[ 4, "asc" ]],
//         "language": {
//           "search": "Search"
//         }
//     });


        
        
//       });



var lang = "<?php echo $lang; ?>";



setInterval (function(){

 $.post("fetch_trading1.php",
      {
        
      },function(data)
      {

         $('tr').each(function (i, el) {
    var $tds = $(this).find('td'),
    Quantity = $tds.eq(5).text();
    if(Quantity>400){
      $tds.eq(5).css("background", "lightgreen");
    }else{
      $tds.eq(5).css("background", "#f59a9a");
    }
   
  });


       $('#table').dataTable().fnClearTable();
         var arr = $.parseJSON(data);
            


           for (var i = 0, len = arr.length; i < len; i++) {
              // console.log("arr[i]", arr[i]["Account_Number"]);
              table.rows.add(
             [[ i+1, arr[i]["Account_Name"], arr[i]["Account_Number"], arr[i]["Account_Balance"], arr[i]["Deposit"], arr[i]["Withdraw"], arr[i]["Account_Equity"], arr[i]["Margin_Level"], arr[i]["Profit_Per"], arr[i]["Profit_Amt"], arr[i]["Highest_Position_Symbol"], arr[i]["Highest_Position_Lot_Size"], arr[i]["Highest_Position_Signal"], arr[i]["Date"] ] ],
          ).draw(); 


              $(".act").text(arr[i]["act"]);
              $(".dep").text(arr[i]["dep"]);
              $(".eq").text(arr[i]["eq"]);

               if(arr[i]["pr"]>0){
                $(".pr").removeClass("redcol");
                $(".pr").addClass("grecol");
              }else{
                $(".pr").removeClass("grecol");
                $(".pr").addClass("redcol");
              }



              $(".pr").text(arr[i]["pr"]);
              $(".wi").text(arr[i]["wi"]);

          }

         $('tr').each(function (i, el) {
    var $tds = $(this).find('td'),
     Quantity = $tds.eq(7).text();
     tod = $tds.eq(8).text();
     pro = $tds.eq(9).text();
     bs = $tds.eq(12).text();
      dep = $tds.eq(4).text();



       $tds.eq(0).css("text-align", "center" );
     // $tds.eq(2).css("text-align", "right" );
     $tds.eq(3).css("text-align", "right" );
     $tds.eq(4).css("text-align", "right" );
     $tds.eq(5).css("text-align", "right" );
     $tds.eq(6).css("text-align", "right" );
     $tds.eq(7).css("text-align", "right" );
     $tds.eq(8).css("text-align", "right" );
      $tds.eq(9).css("text-align", "right" );
     // $tds.eq(10).css("text-align", "right" );
     $tds.eq(11).css("text-align", "right" );




    if(Quantity>400){
      $tds.eq(7).css("background", "lightgreen");
    }else{
      $tds.eq(7).css("background", "#f59a9a");
    }

    if(pro>0){
      $tds.eq(9).css("background", "#fff");
    }else{
      $tds.eq(9).css("background", "#f59a9a");
    }


     if(tod>=0){
      $tds.eq(8).css("background", "#fff");
    }else{
      $tds.eq(8).css("background", "#f59a9a");
    }


    if(bs=="Buy"){
      $tds.eq(12).css("background", "lightgreen");
    }else if(bs=="Sell"){
      $tds.eq(12).css("background", "#f59a9a");
    }else{
      $tds.eq(11).css("background", "#fff");
    }


    if(dep>=0){
      $tds.eq(4).css("background", "#fff");
    }else{
      $tds.eq(4).css("background", "#f59a9a");
    }



   
  });

        
      });





},2000);





if(lang=="JP"){



  var table = $('#table').DataTable({
        "iDisplayLength": 100,
         "aaSorting": [[ 0, "asc" ]],
        "language": {
          "search": "検索",

        },"oLanguage": {
        "sEmptyTable": "表中のデータなし",
        "sLengthMenu": "表示 _MENU_ エントリ",
        "sSearch": "<div style='position: absolute;margin-left: -22px;'>検索</div>",
        "sInfo": "表示中_START_ to _END_ of _TOTAL_ エントリ",
        "sInfoEmpty": "XエントリーのXからXを表示",
        oPaginate: {
            sNext: '次',
            sPrevious: '前'
        }
    },



  });

  
  


$(".adlm").text("アカウントデータ- ライブモニタリング");
$(".tnoa").text("アカウントの総数");
$(".td").text("入金合計");
$(".tp").text("利益合計");
$(".tw").text("出金合計");
$(".an").text("アカウント名");
$(".anum").text("アカウント番号");
$(".ab").text("アカウント残高");
$(".dl").text("入金");
$(".wl").text("出金");
$(".ae").text("有効証拠金");
$(".ml").text("証拠金維持率 (%)");
$(".tpl").text("今日の利益 ($)");
$(".tpl1").text("利益合計 ($)");
$(".hps").text("最大オーダーのペア");
$(".hpls").text("最大オーダーのロットサイズ");
$(".hps1").text("最大オーダーのタイプ");
$(".lp").text("最終位");
$(".te").text("トータルエクイティ");

}else if(lang=="IR"){

   var table = $('#table').DataTable({
        "iDisplayLength": 100,
         "aaSorting": [[ 0, "asc" ]],
        "language": {
          "search": "جستجو",

        },"oLanguage": {
        "sEmptyTable": "هیچ داده ای در جدول موجود نیست",
        "sLengthMenu": "نمایش _MENU_ ورودی های",
        "sSearch": "جستجو",
        "sInfo": "نمایش _START_ to _END_ of _TOTAL_ ورودی های",
        "sInfoEmpty": "نمایش 0 تا 0 از ورودی های 0",
        oPaginate: {
            sNext: 'بعدی',
            sPrevious: 'قبلی'
        }
    },



  });

  
  


$(".adlm").text("نمایش اکانتهای (MT4)به صورت زنده");
$(".tnoa").text("تعداد کل حساب ها");
$(".td").text("کل سپرده");
$(".tp").text("سود کل");
$(".tw").text("برداشت کل");
$(".an").text("نام حساب");
$(".anum").text("شماره حساب");
$(".ab").text("موجودی حساب");
$(".dl").text("سپرده");
$(".wl").text("برداشت");
$(".ae").text("مقدار حقیقی حساب");
$(".ml").text("درصد ظرفیت حساب");
$(".tpl").text("سود امروز ($)");
$(".tpl1").text("سود کل ($)");
$(".hps").text("نماد بالاترین موقعیت");
$(".hpls").text("بزرگترین مقدار خرید");
$(".hps1").text("اندازه لات بالاترین موقعیت");
$(".lp").text("زمان آخرین خرید");
$(".te").text("سرمایه و سود خالص کل حساب ها");


}else{

  var table = $('#table').DataTable({
        "iDisplayLength": 100,
         "aaSorting": [[ 0, "asc" ]],
        "language": {
          "search": "Search"
        }

  });
  
}



</script>

</body>
</html>

