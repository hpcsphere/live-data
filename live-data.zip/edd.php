<?php

		require_once('config.php'); 


		if (isset($_POST['edit'])) {


			$sl = $_POST['sl'];
			$val = $_POST['val'];

			 $sql = "UPDATE `Details` SET `Details`='$val' WHERE `SN`='".$sl."'";

			if($con->query($sql))
			  {   
			    echo "1";
			  }
			  else{
			     echo "Error: " . $sql . "<br>" . $con->error;
			  }

		}elseif (isset($_POST['nate'])) {


			$sl = $_POST['sl'];
			$val = $_POST['val'];
			$txt = $_POST['txt'];

			 $sql = "UPDATE `Details` SET `Nature`='$val', `Nature_txt`='$txt' WHERE `SN`='".$sl."'";

			if($con->query($sql))
			  {   
			    echo "nate";
			  }
			  else{
			     echo "Error: " . $sql . "<br>" . $con->error;
			  }

		}


		elseif (isset($_POST['add'])) {

			$symbol = $_POST['symbol'];
			$price = $_POST['price'];
			$signal = $_POST['signal'];
			$date = date("Y-m-d");

			$sql = "INSERT INTO `Trad`(`Symbol`, `Entry_Price`, `Signal`, `Date` ) VALUES ('$symbol', '$price', '$signal', '$date' )";

			if($con->query($sql))
			  {   
			    


			  	$sql1 = "SELECT * FROM Trad WHERE 1";
			    $result1=$con->query($sql1);
			     $sl = "";
			     while($row1 = $result1->fetch_assoc()) {
			     	
			        $sl = $row1["SN"];
			     }

			     echo $sl;

			  }
			  else{
			     echo "Error: " . $sql . "<br>" . $con->error;
			  }

		}

		else{
			
			$sl = $_POST['sl'];

			$sql = "DELETE FROM `Trad` WHERE `SN`='".$sl."'";

			if($con->query($sql))
			  {   
			    echo "1";
			  }
			  else{
			     echo "Error: " . $sql . "<br>" . $con->error;
			  }

		}


?>