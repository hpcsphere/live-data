<?php session_start();
 require_once('config.php');

  date_default_timezone_set("Asia/Kolkata");

    $i = 1;

    $act = 0;
    $dep = 0;
    $eq = 0;
    $pr = 0;
    $wi = 0;

    $accarr = array();  // for looping through MT4 accounts
    $sql = "SELECT * FROM login WHERE Username = '".$_SESSION['username']."' ";
    $result=$con->query($sql);
    $row = $result->fetch_assoc();
    $accarr = explode (",", $row["MT4_Account"]);
    foreach($accarr as $u)
    {
      $sql = "SELECT * FROM `Live_Trading_Data` WHERE Account_Number= '$u' ";
      $result=$con->query($sql);
      $row = $result->fetch_assoc();
      $act += 1;
      $dep += floatval($row["Deposit"]);
      $eq += floatval($row["Account_Equity"]);
      $pr += floatval($row["Profit_Amt"]);
      $wi += floatval($row["Withdraw"]);
    } // end of foreach

    $arr = array();
    foreach($accarr as $x)
      {
        $sql = "SELECT * FROM Live_Trading_Data WHERE Account_Number= '$x' ";
        $result=$con->query($sql);

        while($row = $result->fetch_assoc()) {


            $crt = gmdate('Y-m-d G:i');
            $oot = date('Y-m-d G:i', strtotime(str_replace('.', '-', $row["ORDER_OPEN_TIME"]) ));

            $time1 = new DateTime($crt);
            $time2 = new DateTime($oot);
            $interval = $time1->diff($time2);

            $days_val = intval($interval->format('%a'));
            $hours_val = ($days_val * 24) + intval($interval->format('%h'));
            $min_val = intval($interval->format('%i'));

            // $res = "";
            // if ($time1 > $time2) {
            //   $res = $hours_val ." h ".$min_val." m ago";
            // } else {
            //   $res = "-". $hours_val ." h ".$min_val." m";
            // }
            // echo $res."<br>";

            if($row["ORDER_OPEN_TIME"]==null || $row["ORDER_OPEN_TIME"]=="" ){

            array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => "NA", 'act' => round($act, 2), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));

          }else{
            // array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => round($row["Account_Equity"], 2), 'Margin_Level' => round($row["Margin_Level"], 2), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => round($row["Account_Balance"], 2), 'Profit_Per' => round($row["Profit_Per"], 2), 'Profit_Amt' => round($row["Profit_Amt"], 2), 'Deposit' => round($row["Deposit"], 2), 'Withdraw' => round($row["Withdraw"], 2), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $interval->format('%a d %h h %i m ago'), 'act' => round($act, 2), 'dep' => round($dep, 2), 'eq' => round($eq, 2), 'pr' => round($pr, 2), 'wi' => round($wi, 2) ));
            // array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => round($row["Account_Equity"], 2), 'Margin_Level' => round($row["Margin_Level"], 2), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => round($row["Account_Balance"], 2), 'Profit_Per' => round($row["Profit_Per"], 2), 'Profit_Amt' => round($row["Profit_Amt"], 2), 'Deposit' => round($row["Deposit"], 2), 'Withdraw' => round($row["Withdraw"], 2), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $interval->format('%H h %i m ago'), 'act' => round($act, 2), 'dep' => round($dep, 2), 'eq' => round($eq, 2), 'pr' => round($pr, 2), 'wi' => round($wi, 2) ));
            if ($time1 > $time2) {
              // array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m ago", 'act' => number_format($act, 2,".",""), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));



              // new1

              array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m ago", 'act' => round($act, 2), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));


            } else {
              // array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m", 'act' => number_format($act, 2,".",""), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));



              // new1

              array_push($arr, array('Account_Name' => $row['Account_Name'],'Account_Number' => $row['Account_Number'], 'Account_Equity' => number_format($row["Account_Equity"], 2,".",""), 'Margin_Level' => number_format($row["Margin_Level"], 2,".",""), 'Highest_Position_Symbol' => $row['Highest_Position_Symbol'], 'Highest_Position_Lot_Size' => $row['Highest_Position_Lot_Size'], 'Account_Balance' => number_format($row["Account_Balance"], 2,".",""), 'Profit_Per' => number_format($row["Profit_Per"], 2,".",""), 'Profit_Amt' => number_format($row["Profit_Amt"], 2,".",""), 'Deposit' => number_format($row["Deposit"], 2,".",""), 'Withdraw' => number_format($row["Withdraw"], 2,".",""), 'Highest_Position_Signal' => $row['Highest_Position_Signal'], 'Date' => $hours_val." h ".$min_val." m", 'act' => round($act, 2), 'dep' => number_format($dep, 2,".",""), 'eq' => number_format($eq, 2,".",""), 'pr' => number_format($pr, 2,".",""), 'wi' => number_format($wi, 2,".","") ));
              


            }
          }



        }
    }
    echo json_encode($arr);
?>