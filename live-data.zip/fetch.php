<table class="table table-bordered" id="table">
    <thead>
  <tr>
   <!--  <th><center>Sl.No.</center></th> -->
    <th>Account Name</th>
    <th>Account Number</th>
    <th>Account Balance</th>
    <th>Account Equity</th>
    <th>Margin Level %</th>
    <th>Profit %</th>
    <th>Profit $</th>
    <th>Highest Position Symbol </th>
    <th>Highest Position Lot Size</th>
  </tr>
</thead>
<tbody>
 <?php
 require_once('config.php');

    $i = 1;

   $sql = "SELECT * FROM Live_Trading_Data WHERE 1";
   $result=$con->query($sql);
   while($row = $result->fetch_assoc()) {



    echo "<tr class='tr'>";
    // echo "<td style='text-align: center;'><center>".$i."</center></td>";
    echo "<td>".$row["Account_Name"]."</td>";
    echo "<td>".$row["Account_Number"]."</td>";
    echo "<td>".$row["Account_Balance"]."</td>";
    echo "<td>".$row["Account_Equity"]."</td>";

    if($row["Margin_Level"]>400){
      echo "<td style='background: lightgreen;'>".$row["Margin_Level"]."</td>";
    }else{
      echo "<td style='background: #f59a9a;'>".$row["Margin_Level"]."</td>";
    }

     echo "<td>".$row["Profit_Per"]."</td>";
     echo "<td>".$row["Profit_Amt"]."</td>";

    

    echo "<td>".$row["Highest_Position_Symbol"]."</td>";
    echo "<td>".$row["Highest_Position_Lot_Size"]."</td>";

  

    
    echo "</tr>";

    $i++;

   }

  ?>
</tbody>
</table>

