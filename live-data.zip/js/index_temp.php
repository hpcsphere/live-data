<?php
  session_start();

  // if(isset($_SESSION['login_user']) ){
  // }else{
  //   header("Location: ../");
  // }

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html>
<head>
 

 <title>Live Account Data</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>
<style>

</style>
<body>

  <header style=" height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
     ">Live Account Data







   </header> 

    

<br><br>
<div class="container">

  <!-- <div align="center">
      <div class="form-group" style="display: inline-flex;width: 100%;justify-content: center;">
        <form>
          <label>Symbol:</label>
          <input type="text" name="Symbol" id="symbol" placeholder="Please enter Symbol" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;
          <label>Entry Price:</label>
        <input type="text" name="Entry Price" id="price" placeholder="Please enter Entry Price" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;

         <label>Signal:</label>
       <select id="signal" style="height: 28px;width: 70px;">
        <option class="null">Buy</option>
        <option>Sell</option>
       </select>&nbsp;&nbsp;

          <button class="btn btn-success add"><i class="fa fa-plus"></i>&nbsp;&nbsp;<i class="fa fa-spinner fa-spin" style="font-size: 17px;position: absolute;margin-top: -1px;display:none ;"></i>Add Trading Point</button>
        </form>
      </div>
     
    </div>

     <span style="    font-size: 15px;
    color: green;
    position: absolute;
    left: 42%;
    margin-top: 12px;">

      <?php echo date("d-M-Y"); echo " ";

        $date = new DateTime();
        $timeZone = $date->getTimezone();
        echo $timeZone->getName();



       ?>
       <span id="zone"></span>
     </span> -->

          
 <!--  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    <th>Account Number</th>
    <th>Account Equity</th>
    <th>Margin Level %</th>
    <th>Highest Position Symbol </th>
    <th>highest Position Lot Size</th>
  </tr>
</thead>
<tbody>
 
</tbody>
</table> -->
  
  <table class="table table-bordered" id="table">
    <thead>
  <tr>
   <!--  <th><center>Sl.No.</center></th> -->
    <th>Account Name</th>
    <th>Account Number</th>
    <th>Account Balance</th>
    <th>Account Equity</th>
    <th>Margin Level %</th>
    <th>Today's Profit&nbsp;(&nbsp;$&nbsp;)</th>
    <th>Total Profit&nbsp;(&nbsp;$&nbsp;)</th>
    <th>Highest Position Symbol </th>
    <th>Highest Position Lot Size</th>
  </tr>
</thead>
<tbody>
 <?php
 require_once('config.php');

    $i = 1;

   $sql = "SELECT * FROM Live_Trading_Data WHERE 1";
   $result=$con->query($sql);
   while($row = $result->fetch_assoc()) {



    echo "<tr class='tr'>";
    // echo "<td style='text-align: center;'><center>".$i."</center></td>";
    echo "<td>".$row["Account_Name"]."</td>";
    echo "<td>".$row["Account_Number"]."</td>";
    echo "<td>".$row["Account_Balance"]."</td>";
    echo "<td>".$row["Account_Equity"]."</td>";

    if($row["Margin_Level"]>400){
      echo "<td style='background: lightgreen;' class='ml'>".$row["Margin_Level"]."</td>";
    }else{
      echo "<td style='background: #f59a9a;' class='ml'>".$row["Margin_Level"]."</td>";
    }

     echo "<td>".$row["Profit_Per"]."</td>";
     echo "<td>".$row["Profit_Amt"]."</td>";

    

    echo "<td>".$row["Highest_Position_Symbol"]."</td>";
    echo "<td>".$row["Highest_Position_Lot_Size"]."</td>";

  

    
    echo "</tr>";

    $i++;

   }

  ?>
</tbody>
</table>




</div>


<div id="deleteModal" class="modal">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
             <h4 class="modal-title">Trade Points Management</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
           
          </div>
          <div class="modal-body">
            <p>Do you really want to delete?</p>
          </div>
          <div class="modal-footer">
            <!-- <p style="color: green;position: absolute;left: 17px;display: none;" id="pd"><i class="fa fa-check"></i>&nbsp;Project Deleted Successfully.</p> -->
            <!-- <p style="color: red;position: absolute;left: 17px;display: none;" id="pnd"><i class="fa fa-times"></i>&nbsp;Project Not Delete!</p> -->
        <button type="button" class="btn btn-danger yes"><i class="fa fa-check"></i><i class="fa fa-spinner fa-spin" style="font-size: 17px;position: absolute;margin-top: -1px;display:none ;"></i>&nbsp; Yes</button>
        <button type="button" class="btn btn-default cl" data-dismiss="modal" style="border: 1px solid lightgrey;"><i class="fa fa-times"></i>&nbsp; No</button>
          </div>
        </div>

      </div>
    </div>


    <div id="abv16" class="modal">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
             <h4 class="modal-title">Trade Points Management</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
           
          </div>
          <div class="modal-body">
            <p>16 trading points have already been defined for today <?php echo date("d-M-Y"); ?></p>
          </div>
          <div class="modal-footer">
            <!-- <p style="color: green;position: absolute;left: 17px;display: none;" id="pd"><i class="fa fa-check"></i>&nbsp;Project Deleted Successfully.</p> -->
            <!-- <p style="color: red;position: absolute;left: 17px;display: none;" id="pnd"><i class="fa fa-times"></i>&nbsp;Project Not Delete!</p> -->
       
        <button type="button" class="btn btn-default cl" data-dismiss="modal" style="border: 1px solid lightgrey;"><i class="fa fa-times"></i>&nbsp; Close</button>
          </div>
        </div>

      </div>
    </div>

<script>

 
  

  var table = $('#table').DataTable({
        "iDisplayLength": 100,
         "aaSorting": [[ 4, "asc" ]],
        "language": {
          "search": "Search"
        }

  });
  

 
// $.post("fetch.php",
//       {
        
//       },function(data)
//       {
        
//         $("#tbdiv").html(data);

//         var table = $('#table').DataTable({
//         "iDisplayLength": 100,
//          "aaSorting": [[ 4, "asc" ]],
//         "language": {
//           "search": "Search"
//         }
//     });


        
        
//       });




setInterval (function(){

 $.post("fetch_trading_temp.php",
      {
        
      },function(data)
      {

         $('tr').each(function (i, el) {
    var $tds = $(this).find('td'),
    Quantity = $tds.eq(4).text();
    if(Quantity>400){
      $tds.eq(4).css("background", "lightgreen");
    }else{
      $tds.eq(4).css("background", "#f59a9a");
    }
   
  });


       $('#table').dataTable().fnClearTable();
         var arr = $.parseJSON(data);
           
           for (var i = 0, len = arr.length; i < len; i++) {
              // console.log("arr[i]", arr[i]["Account_Number"]);
              table.rows.add(
             [[ arr[i]["Account_Name"], arr[i]["Account_Number"], arr[i]["Account_Balance"], arr[i]["Account_Equity"], arr[i]["Margin_Level"], arr[i]["Profit_Per"], arr[i]["Profit_Amt"], arr[i]["Highest_Position_Symbol"], arr[i]["Highest_Position_Lot_Size"]] ],
          ).draw(); 
          }

         $('tr').each(function (i, el) {
    var $tds = $(this).find('td'),
    Quantity = $tds.eq(4).text();
    if(Quantity>400){
      $tds.eq(4).css("background", "lightgreen");
    }else{
      $tds.eq(4).css("background", "#f59a9a");
    }
   
  });

        
      });




},2000);






</script>

</body>
</html>

