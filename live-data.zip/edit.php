<?php session_start();

if(isset($_SESSION['id']) && isset($_SESSION['username'])){
 
}
else{
    
    header("Location: login.php");
}

   require_once('config.php');

   date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html>
<head>
 

 <title>MT4 Account Data - Live Monitoring</title>
  <meta charset="utf-8">
 <link rel="icon" type="image/x-icon" href="logo.png" />
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-csv/0.71/jquery.csv-0.71.min.js"></script>
    <script src="js/moment.js"></script>
</head>
<style>

  .btns {

        width: 100px;
    overflow-x: hidden;
    cursor: default ! important;
    background-color: #ccc;
  }

  .btd {
        margin-left: 10px;
            padding: 5px;
  }

  .bord {
        border-left: 1px solid lightgrey;
    padding-left: 10px;
  }


  .logout {
        position: absolute;
    right: 20px;
    top: 20px;
    font-size: 20px;
    cursor: pointer;
    color: red;
  }

  .header {
    height: 60px;
    padding: 8px;
   
    z-index: 9999;
    width: 100%;
    background-color: #fff;
      -webkit-box-shadow: 0 1px 2px rgb(0 0 0 / 30%);
    box-shadow: 1px 2px 13px rgb(0 0 0 / 30%);
    text-align: center;
    padding-top: 11px;
    font-size: 25px;
  }





.switch {
  position: relative;
  display: inline-block;
          width: 54px;
    height: 25px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
      height: 18px;
    width: 18px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}


.mt4 {
      width: 50%;
}

.deletebtn {
      right: 130px !important;
}

.custom-select-sm {
        width: 50px;
  }

  .dataTables_filter>label {
        display: inline-flex;
        position: relative;
    left: 10px;
  }


  .fa-pencil{

        font-size: 15px;
    color: #2db4ec;

  }

  #table_wrapper {
            width: 106.8%;
  }


</style>
<body>

  <header class="header" style=" 
     ">MT4 Account Data - Live Monitoring


<a href="logout.php"><i class="fa fa-sign-out logout" aria-hidden="true" title="Logout" ></i></a>





   </header> 

   <?php

    require_once("sidenavbar.html");


   ?>

    

<br><br>
<div class="container" style="padding-left:0px">

  <!-- <div align="center">
      <div class="form-group" style="display: inline-flex;width: 100%;justify-content: center;">
        <form>
          <label>Symbol:</label>
          <input type="text" name="Symbol" id="symbol" placeholder="Please enter Symbol" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;
          <label>Entry Price:</label>
        <input type="text" name="Entry Price" id="price" placeholder="Please enter Entry Price" style="height: 28px;width: 170px;" required>&nbsp;&nbsp;

         <label>Signal:</label>
       <select id="signal" style="height: 28px;width: 70px;">
        <option class="null">Buy</option>
        <option>Sell</option>
       </select>&nbsp;&nbsp;

          <button class="btn btn-success add"><i class="fa fa-plus"></i>&nbsp;&nbsp;<i class="fa fa-spinner fa-spin" style="font-size: 17px;position: absolute;margin-top: -1px;display:none ;"></i>Add Trading Point</button>
        </form>
      </div>
     
    </div>

     <span style="    font-size: 15px;
    color: green;
    position: absolute;
    left: 42%;
    margin-top: 12px;">

      <?php echo date("d-M-Y"); echo " ";

        $date = new DateTime();
        $timeZone = $date->getTimezone();
        echo $timeZone->getName();



       ?>
       <span id="zone"></span>
     </span> -->

          
 <!--  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    <th>Account Number</th>
    <th>Account Equity</th>
    <th>Margin Level %</th>
    <th>Highest Position Symbol </th>
    <th>highest Position Lot Size</th>
  </tr>
</thead>
<tbody>
 
</tbody>
</table> -->


<div class="main">

  <span style="    position: absolute;
    left: 48%;
    margin-top: 0px;color: green;display: none;" class="upmsg"><i class="fa fa-check"></i>&nbsp;&nbsp;Successfully updated.</span>

    <span style="    position: absolute;
    left: 48%;
    margin-top: 0px;color: green;display: none;" class="upmsg1"><i class="fa fa-check"></i>&nbsp;&nbsp;Language changed to <span class="lanm"></span> </span>

  <table class="table table-bordered" id="table">
    <thead>
  <tr>
    <th><center>Sl.No.</center></th>
    <th>Client Name <i class="fa fa-pencil" ></i></th>
    <th>Login Email ID</th>
    <th>Password  <i class="fa fa-pencil" ></i></th>
    <th>Linked MT4 Accounts</th>
    <th>Total Deposit</th>
    <th>Total Equity</th>
    <th>Total Profit</th>
    <th>Total Withdraw</th>
    <th>Language  <i class="fa fa-pencil" ></i></th>
    <th>Enable/Disable Client  <i class="fa fa-pencil" ></i></th>
    <th>Delete</th>
   
  </tr>
</thead>
<tbody>
 <?php
 require_once('config.php');

    $i1 = 1;

   $sql = "SELECT * FROM login WHERE Username !='admin' ";
   $result=$con->query($sql);
   while($row = $result->fetch_assoc()) {



   echo "<tr class='tr' id='".$row["SN"]."''>";
  
    echo "<td>".$i1."</td>";
    echo "<td contenteditable class='name'>".$row["Name"]."</td>";
    echo "<td class='email'>".$row["Username"]."</td>";
    echo "<td contenteditable class='pass' >".$row["Password"]."</td>";
    echo "<td><span style='display:none;' class='mta'>".$row["MT4_Account"]."</span><button class='btn btn-success mt4btn'><i class='fa fa-eye'></i>&nbsp;MT4 Accounts</button></td>";

    $array = explode(',', $row["MT4_Account"]);

    
    $dep = 0;
    $eq = 0;
    $pr = 0;
    $wi = 0;


    for ($i=0; $i < sizeof($array); $i++) { 
      


       $sql1 = "SELECT * FROM `Live_Trading_Data` WHERE Account_Number='".$array[$i]."' ";
       $result1=$con->query($sql1);
       while($row1 = $result1->fetch_assoc()) {
        $dep = $row1["Deposit"]+$dep;
        $eq = $row1["Account_Equity"]+$eq;
        $pr = $row1["Profit_Amt"]+$pr;
        $wi = $row1["Withdraw"]+$wi;
       }


    }

    echo "<td align ='right'>".number_format($dep, 2,".","")."</td>";
    echo "<td align ='right'>".number_format($eq, 2,".","")."</td>";


    if($pr>=0){
       echo "<td align ='right'>".number_format($pr, 2,".","")."</td>";
    }else{ 
       echo "<td align ='right' style='background: #f59a9a;'>".number_format($pr, 2,".","")."</td>";
    }

   
    echo "<td align ='right'>".number_format($wi, 2,".","")."</td>";

    $arr = ["EN","JP","IR"];

    echo "<td><select class='btn btn-default lang' style='border:1px solid lightgrey;'>";

    for ($i=0; $i <sizeof($arr) ; $i++) { 
      if($arr[$i]=="JP"){
        if($arr[$i]==$row["Language"]){
          echo "<option value='".$arr[$i]."' selected>Japanese (JP)</option>";
        }else{
          echo "<option value='".$arr[$i]."'>Japanese (JP)</option>";
        }
        
      }elseif($arr[$i]=="IR"){
         if($arr[$i]==$row["Language"]){
          echo "<option value='".$arr[$i]."' selected>Persian (IR)</option>";
        }else{
          echo "<option value='".$arr[$i]."'>Persian (IR)</option>";
        }
        
      }else{
         if($arr[$i]==$row["Language"]){
           echo "<option value='".$arr[$i]."' selected>English (EN)</option>";
        }else{
           echo "<option value='".$arr[$i]."'>English (EN)</option>";
        }
       

      }
      
    }

    echo "</select></td>";


    if($row["Status"]==0){
      echo '<td><label class="switch">
  <input type="checkbox" checked>
  <span class="slider round"></span>
</label></td>';
    }else{
      echo '<td><label class="switch">
  <input type="checkbox" >
  <span class="slider round"></span>
</label></td>';
    }

    
   

   echo '<td><button class="btn btn-danger delbtn"><i class="fa fa-trash"></i>&nbsp;Delete</button></td>';

    
    echo "</tr>";

    $i1++;

   }

  ?>

</tbody>
</table>









</div>

</div>




<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

        <div class="ne">
                  
        </div>
        
        <form class="form-horizontal form" style="position: relative;
    left: 91px;"></form>



        <button class="btn btn-success addbtn" type="button" style="    position: relative;
    left: 100px;
    margin-bottom: 10px;    width: 277px;" ><i class="fa fa-plus"></i>&nbsp; Add Another MT4 Account</button>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

        <center class="msgs" style="color:green;position: absolute;
    left: 45%;display: none;">Account Saved!</center>
        <!-- <center class="dupmsg1" style="color:red;position: absolute;
    left: 45%;display: none;">This MT4 account number is already present in database.</center> -->
        <div  class="dupmsg1" style="position: absolute; left: 30%; margin-top:0%; color:red; display: none;">MT4 account number already exists!</div>
        <!-- <div  class="dupmsg1" style="position: absolute; left: 30%; color:red; display: none;"></div> -->
        <!-- <center class="dupmsg2" style="color:red;position: absolute;
    left: 45%;display: none;">Account already exists!</center> -->
        <!-- <div  class="dupmsg2" style="position: absolute; left: 35%; margin-top:4%; color:red; display: none;">Duplicate MT4 account!</div> -->

        <button type="button" class="btn btn-primary" data-dismiss="modal" style="    position: relative;
    right: 98px;">Done</button>
        <!-- <button id="donebtn" type="button" class="btn btn-primary" style="    position: relative;
    right: 98px;">Done</button> -->
      </div>

    </div>
  </div>
</div>










<!-- The Modal -->
<div class="modal" id="delModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">MT4 Account Data - Live Monitoring</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

      
        <p>Do you really want to delete this client?<br>All data related to all the accounts of this client will be deleted!</p>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">

        <center class="delmsg" style="color:red;position: absolute;
    left: 45%;display: none;">Client Deleted!</center>

        <button type="button" class="btn btn-success yesbtn">Yes</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>



<?php

      $sql = "SELECT MT4_Account FROM `login` WHERE Username !='admin' ";
       $result=$con->query($sql);
      $mt4a = "";

      while($row = $result->fetch_assoc()) {
        $mt4a .= $row["MT4_Account"].",";
     }



  ?>
  


<script>


var str1 = "<?php echo $mt4a; ?>";


  


  var table = $('#table').DataTable({
        "iDisplayLength": 100,
        
        "language": {
          "search": "Search"
        }

  });
  

 


$(".users").addClass("active");

var namei = "";
var passi = "";

$(document).on("focusin",".name",function(){

  namei = $(this).text();


});

$(document).on("focusin",".pass",function(){

  passi = $(this).text();
 

});



$(document).on("focusout",".name",function(){

  var name = $(this).text();
  var sl = $(this).parent("tr").attr("id");

  if(namei==name){

  }else{
    $.post( "update.php", { name,sl })
      .done(function( data ) {

        $(".upmsg").fadeIn().fadeOut(3000);
        
      });
  }

   


});


$(document).on("focusout",".pass",function(){

  var pass = $(this).text();
  var sl = $(this).parent("tr").attr("id");

  if(passi==pass){

  }else{
     $.post( "update.php", { pass,sl })
      .done(function( data ) {

        $(".upmsg").fadeIn().fadeOut(3000);
        
      });
  }

 

});


$(".slider").click(function(){

  var sl = $(this).parent("label").parent("td").parent("tr").attr("id");

  if($(this).siblings("input").is(':checked'))
  {
   
    var status = 1;
    $.post( "update.php", { status,sl })
      .done(function( data ) {

        
        
      });
  }else
  {
  var status = 0;
   $.post( "update.php", { status,sl })
      .done(function( data ) {

        
        
      });
  }



});



var mt4 = 0;
var mt4t = 0;
var thi = "";
var sl = "";

// $("#donebtn").click(function(){
// // $(document).on("focusout","#donebtn",function(){
//   $("#donebtn").removeAttr("data-dismiss");
//   // $('#donebtn').prop('disabled', false);
//   var total = $('.mt4').length-1;
//   var accts = [];
//     $(".mt4").each(function(index){
//       var x = $(this).val();
//       accts.push(x);
//     });
//     lastItem = accts[total];
//     var dupFlag = false;
//     for (var i = 0; i < accts.length-1; i++) {
//       if (accts[i] === lastItem) {
//         dupFlag = true;
//       }
//     }
//     if (dupFlag == true){
//       $(".dupmsg").fadeIn().fadeOut(2000);
//       // $('#donebtn').prop('disabled', true);
//     } else {
//       // $('#donebtn').prop('disabled', false);
//       $("#donebtn").attr("data-dismiss","modal");  
//     }
// });

$(".mt4btn").click(function(){

mt4 = 0;
mt4t = 0;

sl = $(this).parent("td").parent("tr").attr("id");

thi = this;

  var acc = "["+$(this).siblings("span").text()+"]";

  var parse = JSON.parse(acc);

  var html = "";


  for (var i = 0; i < parse.length; i++) {
    

    if(i==parse.length-1){
      // html += '<div class="form-group mt4'+i+'" data="mt4'+i+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="text" value="'+parse[i]+'" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required disabled ><button class="btn btn-success addbtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-plus"></i></button><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -45px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>';


       html += '<div class="form-group mt4'+i+'" data="mt4'+i+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" value="'+parse[i]+'" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required disabled><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>';

    }else{
      html += '<div class="form-group mt4'+i+'" data="mt4'+i+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" value="'+parse[i]+'" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required disabled><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>';
    }

    
    mt4 = mt4+1;
    mt4t = mt4t+1;

  }

  mt4 = mt4-1;
  mt4t = mt4t-1;



  $(".form").html(html);



  var name = $(this).parent("td").siblings(".name").text();
  var email = $(this).parent("td").siblings(".email").text();

  
  $(".ne").html("<p><b>"+name+" | "+email+"</b></p>");


    $("#myModal").modal();

});




$(document).on("focusout",".mt4",function(){

var mt4 = "";
var total = $('.mt4').length-1;

if($(this).val()=="" || $(this).val()==null ){

  }else{

var txt = $(thi).siblings("span").text();

// var acc = "["+txt+"]";
// var parse = JSON.parse(acc);

var accts = [];
$(".mt4").each(function(index){
  var x = $(this).val();
  accts.push(x);
});

lastItem = accts[total];
var dupFlag = false;
for (var i = 0; i < accts.length-1; i++) {
  if (accts[i] === lastItem) {
    dupFlag = true;
  }
}

if (dupFlag == true){
  // $(".dupmsg1").after('<div  class="dupmsg1" style="position: absolute; left: 30%; color:red; display: none;">MT4 account number already exists!</div>')
  $(".dupmsg1").fadeIn().fadeOut(2000);

  $(this).css("border","1px solid red");

} else {

  

if(str1.indexOf($(this).val()) != -1){
  $(".dupmsg1").fadeIn().fadeOut(2000);
}else{

  str1 +=$(this).val()+",";


        console.log("str1", str1);


  $(this).css("border","1px solid #ced4da");

$(".mt4").each(function(index){
 var l = $(this).val();

   // if($(this).val()=="" || $(this).val()==null ){
    if(l.length==0 ){
      mt4 = mt4.substring(mt4.length-1, mt4.lastIndexOf(" "));

   }else{
    if(total==index){
      mt4 +=$(this).val();
    }else{
      mt4 +=$(this).val()+",";
    }
   }
    
    
  });


$(thi).siblings("span").text(mt4);

$.post( "update.php", { mt4,sl })
  .done(function( data ) {

    $(".msgs").fadeIn().fadeOut(2000);
    
  });


   }




}


}


});


$("body").delegate(".addbtn", "click", function(){

  // var val = document.getElementsByClassName("dupmsg1")[0];
  // val.innerHTML = "Duplicate MT4 account!";

  var total = $('.mt4').length-1;
  var accts = [];
    $(".mt4").each(function(index){
      var x = $(this).val();
      accts.push(x);
    });
    lastItem = accts[total];
    var dupFlag = false;
    for (var i = 0; i < accts.length-1; i++) {
      if (accts[i] === lastItem) {
        dupFlag = true;
      }
    }

    if (dupFlag == true){
      $(".dupmsg1").fadeIn().fadeOut(2000);
      // $(".mt4"+mt4).attr("style", "background-color: red;");
      // const msg = document.getElementsByClassName("dupmsg1").innerHTML;
      // if (msg == "") {
      //   console.log("Empty")
      // } else {
      //   console.log("NOT Empty")
      //   console.log(msg);
      // }
      // $(".dupmsg1").after('<div  class="dupmsg1" style="position: absolute; left: 30%; color:red; display: none;">Duplicate MT4 account!</div>')
      // $(".dupmsg1").fadeIn().fadeOut(2000);
    } else {
       console.log("mt4", mt4);
       if(mt4<0){
        $(".form").html('<div class="form-group mt40" data="mt40" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required ><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>');
        mt4 = mt4+1;
         console.log("demo", mt4);
       }else{

     

      if($(".mt4"+mt4).children("div").children("input").val()==null || $(".mt4"+mt4).children("div").children("input").val()=="" && !$(".mt4"+mt4).hasClass("none")  ){
        $(".mt4"+mt4).children("div").children("input").css("border", "1px solid orange");
        console.log("mt41", mt4);
      }else{
        console.log("mt42", mt4);

        $(".mt4"+mt4).children("div").children("input").css("border", "1px solid #ced4da");

    var mt41 = mt4+1

    $(".mt4"+mt4).children("div").children(".addbtn").remove();
    $(".mt4"+mt4).children("div").children(".deletebtn").css("right", "-15px" );


    // $(".mt4"+mt4).after('<div class="form-group mt4'+mt41+'" data="mt4'+mt41+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="text" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required ><button class="btn btn-success addbtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-plus"></i></button><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -45px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>');
    $(".mt4"+mt4).after('<div class="form-group mt4'+mt41+'" data="mt4'+mt41+'" style="width: 90%;"><label class="control-label col-sm-3" for="mt4">MT4 Account:</label> <div class="col-sm-9"><input type="number" class="form-control mt4 " placeholder="Enter MT4 Account" name="mt4" required ><button class="btn btn-danger deletebtn" type="button" style="position: absolute; right: -15px;top: 0px;" ><i class="fa fa-trash"></i></button></div></div>');

  mt4 = mt4+1;

  }



}



  }


});


$("body").delegate(".deletebtn", "click", function(){

  if($(this).siblings("button").hasClass("addbtn")){
    // console.log("class", $(this).parent("div").parent("div").attr("data") );
  }else{
    // $(this).parent("div").parent("div").remove();



    $(this).parent("div").parent("div").css("display", "none");
    $(this).parent("div").parent("div").addClass("none");
    $(this).siblings("input").removeClass("mt4");

  }


 var mt4 = "";
    var total = $('.mt4').length-1;

   $(".mt4").each(function(index){
       if($(this).val()=="" || $(this).val()==null ){

       }else{
        if(total==index){
          mt4 +=$(this).val();
        }else{
          mt4 +=$(this).val()+",";
        }
       }
        
        
      });


   $(thi).siblings("span").text(mt4);

   $.post( "update.php", { mt4,sl })
      .done(function( data ) {

        mt4t = mt4t-1;
        
      });


});


var sn = "";
var del = "";
var mta = "";


$(".delbtn").click(function(){

  del = this;

   sn = $(this).parent("td").parent("tr").attr("id");

   mta = $(this).parent("td").siblings("td").children(".mta").text();



  $("#delModal").modal();


});


$(".yesbtn").click(function(){


  




    $.post( "update.php", { sn,mta })
      .done(function( data ) {

        $(".delmsg").fadeIn().fadeOut(2000);
        $(del).parent("td").parent("tr").remove();
        ser();
        $("#delModal").modal("toggle");
        
      });


});



function ser(){
  var i = 1;
  var sizeofrows=(table.rows().data()).length;
 
  $(".tr").each(function(){


   $( this ).find( "td:eq(0)" ).text(i)

    i++;
    
  });
}





$(document).on("change",".lang",function(){

  var lang = $(this).val();
  var lang1 = $(this).find(":selected").text();
  var sl = $(this).parent("td").parent("tr").attr("id");
  


   $.post( "update.php", { lang,sl })
      .done(function( data ) {



        $(".lanm").text(lang1);

      $(".upmsg1").fadeIn().fadeOut(3000);
        
      });


});


</script>

</body>
</html>

